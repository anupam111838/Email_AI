# AI Email Assistant - Detailed Setup Guide

## Project Overview

This is an **AI Email Assistant** powered by **Ollama (Local AI Models)** and **Google Gmail API (OAuth 2.0)**. It provides a web interface to:
- Read and analyze unread emails from your Gmail account
- Generate AI-powered summaries and draft replies
- Optionally send replies automatically
- Monitor email processing in real-time with a modern UI

---

## System Requirements

- **Python** 3.10 or higher
- **Ollama** (for running local AI models)
- **Git** (recommended for version control)
- **Linux/macOS/Windows** with 2GB RAM minimum
- **Internet connection** (for Gmail API & initial Ollama model download)

---

## Prerequisites Installation

### 1. Install Python 3.10+

**Linux (Ubuntu/Debian):**
```bash
sudo apt update
sudo apt install python3 python3-pip python3-venv
python3 --version  # Verify installation
```

**macOS:**
```bash
brew install python@3.11
python3 --version  # Verify installation
```

**Windows:**
- Download from https://www.python.org/downloads/
- Run installer and check "Add Python to PATH"
- Verify: Open PowerShell and run `python --version`

---

### 2. Install Ollama

Ollama runs local AI models without needing external APIs or GPU.

**Step 1: Download & Install**
```bash
# Visit https://ollama.com and download for your OS
# OR for Linux:
curl -fsSL https://ollama.ai/install.sh | sh
```

**Step 2: Start Ollama Service**
```bash
# Linux/macOS: Ollama should auto-start after installation
# Verify it's running:
curl http://localhost:11434/api/tags
```

**Step 3: Pull AI Model**
```bash
# Pull the granite4 model (or your preferred model)
ollama pull granite4:latest

# Verify model is downloaded:
ollama list
```

> **Note:** The first run of a model may take a while as it downloads weights. Models are cached locally after first use.

---

## Project Setup

### Step 1: Clone / Extract Project

Navigate to your project directory:
```bash
cd "/media/nepra/nepra-1 TB/Projects/agentic_ai/updated/openclaw/email_assistant_ollama"
```

### Step 2: Create Virtual Environment

Create an isolated Python environment to avoid dependency conflicts:

**Linux/macOS:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**Windows (PowerShell):**
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

**Windows (Command Prompt):**
```cmd
python -m venv venv
venv\Scripts\activate.bat
```

You should see `(venv)` in your terminal prompt.

### Step 3: Install Python Dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

**Installed packages:**
- `google-api-python-client==2.115.0` — Gmail API
- `google-auth-oauthlib==1.2.0` — OAuth 2.0 authentication
- `ollama>=0.2.1` — Ollama client library
- `Flask==3.0.0` — Web framework
- `waitress==3.0.1` — Production-grade server
- `python-dotenv==1.0.1` — Environment variable management

---

## Google OAuth 2.0 Setup

The application uses Gmail API via OAuth 2.0. You need to create credentials from Google Cloud.

### Step 1: Create Google Cloud Project

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. **Create a new project:**
   - Click "Select a Project" → "NEW PROJECT"
   - Name it: `Email Assistant`
   - Click "Create"

3. **Enable Gmail API:**
   - In the search bar, search for "Gmail API"
   - Click "Enable"

### Step 2: Create OAuth 2.0 Credentials

1. Go to **"Credentials"** (left sidebar)
2. Click **"+ Create Credentials"** → **"OAuth client ID"**
3. If prompted to create a consent screen:
   - Choose **"External"** user type
   - Click **"Create"**
   - Fill required fields (App name, User support email, etc.)
   - Scroll to bottom and click **"Save and Continue"**
   - Skip scopes, click **"Save and Continue"**
   - Click **"Back to Dashboard"**

4. Now create OAuth client credentials:
   - Click **"+ Create Credentials"** → **"OAuth client ID"**
   - Select **"Web application"**
   - Under "Authorized redirect URIs," add:
     ```
     http://localhost:5000/oauth/callback
     http://localhost:8080/oauth/callback
     ```
   - Click **"Create"**

5. **Download your credentials:**
   - Click the download icon (↓) next to your credentials
   - Save as `credentials.json` in your project root directory

### Step 3: Place Credentials File

```bash
# Copy downloaded credentials to project root
cp ~/Downloads/credentials.json .
```

---

## Environment Configuration

### Step 1: Create .env File

```bash
# Copy example (if available) or create new:
touch .env
```

### Step 2: Fill in .env File

Open `.env` with your text editor and add:

```env
# Gmail Configuration
EMAIL_ADDRESS=your-email@gmail.com

# Ollama Configuration
OLLAMA_BASE_URL=http://localhost:11434
OLLAMA_MODEL=granite4:latest

# Application Settings
AUTO_SEND=False          # Set to True to auto-send replies
UNREAD_FETCH_LIMIT=10    # Max emails to fetch per poll (1-50)
EMAIL_QUEUE_LIMIT=200    # Max emails to keep in UI (1-500)
```

**Configuration Details:**

| Variable | Default | Description |
|----------|---------|-------------|
| `EMAIL_ADDRESS` | - | Your Gmail email address |
| `OLLAMA_BASE_URL` | `http://localhost:11434` | Ollama server URL (local by default) |
| `OLLAMA_MODEL` | `gemma3` | AI model to use (e.g., `granite4:latest`, `llama2`, `mistral`) |
| `AUTO_SEND` | `False` | Auto-send replies without approval |
| `UNREAD_FETCH_LIMIT` | `10` | Emails fetched per request (1-50) |
| `EMAIL_QUEUE_LIMIT` | `200` | Max emails stored in UI (1-500) |

---

## Running the Application

### Step 1: Ensure Ollama is Running

```bash
# Check if Ollama is available:
curl http://localhost:11434/api/tags

# If not running, start Ollama:
ollama serve  # (Usually runs automatically on Linux/macOS)
```

### Step 2: Start the Flask Application

```bash
# Make sure virtual environment is activated:
source venv/bin/activate  # (or your OS-specific activation)

# Start the application:
python app.py
```

You should see output like:
```
 * Running on http://127.0.0.1:5000
 * Debug mode: off
```

### Step 3: Access the Web Interface

Open your browser and go to:
```
http://localhost:5000
```

### Step 4: Authenticate with Google

1. Click **"Sign in with Google"**
2. Select your Gmail account
3. Grant permissions when prompted
4. You'll be redirected back to the app (authenticated)

---

## Common Tasks

### Check Ollama Models

```bash
ollama list
```

### Change AI Model

Edit `.env` and update:
```env
OLLAMA_MODEL=llama2:latest
```

Then restart the application.

### Download Additional Models

```bash
ollama pull llama2:latest
ollama pull mistral:latest
```

### Stop the Application

Press `Ctrl+C` in the terminal running the Flask app.

### Deactivate Virtual Environment

```bash
deactivate
```

---

## Troubleshooting

### Issue: "ConnectionError: Unable to connect to Ollama"
**Solution:** 
- Verify Ollama is running: `curl http://localhost:11434/api/tags`
- Check `OLLAMA_BASE_URL` in `.env` is correct
- Restart Ollama service

### Issue: "Gmail API not enabled"
**Solution:**
- Go to [Google Cloud Console](https://console.cloud.google.com/)
- Search for "Gmail API"
- Click "Enable"

### Issue: "Invalid redirect URI"
**Solution:**
- Go to OAuth credentials in Google Cloud Console
- Update "Authorized redirect URIs" to include:
  - `http://localhost:5000/oauth/callback`
  - `http://localhost:8080/oauth/callback`

### Issue: Import errors after installing dependencies
**Solution:**
```bash
# Reinstall in a fresh virtual environment:
deactivate
rm -rf venv
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### Issue: Model download very slow
**Solution:**
- Models are large (1-8GB), downloads depend on internet speed
- Models are cached locally after first use
- Consider scheduling downloads during off-peak hours

---

## Project Architecture

```
email_assistant_ollama/
├── app.py                 # Flask application & web routes
├── email_service.py       # Gmail API integration
├── ai_service.py          # Ollama AI processing
├── config.py              # Configuration management
├── credentials.json       # OAuth 2.0 credentials (not in repo)
├── .env                   # Environment variables (not in repo)
├── requirements.txt       # Python dependencies
├── templates/             # HTML templates
│   ├── index.html         # Main web interface
│   └── index_1.html       # Alternative layout
├── static/                # Static assets
│   ├── css/               # Stylesheets
│   │   ├── style.css
│   │   └── style_1.css
│   └── js/                # JavaScript
│       ├── app.js
│       └── app_1.js
└── .gitignore             # Excluded files (credentials, .env)
```

---

## Optional: Running on a Production Server

For production deployment, use a proper WSGI server:

```bash
waitress-serve --port=8080 app:app
```

Access via: `http://your-server-ip:8080`

**Note:** For public access, consider:
- Setting up HTTPS with self-signed or valid certificates
- Running behind a reverse proxy (nginx)
- Restricting access with firewall rules

---

## Next Steps

1. ✅ Complete the setup above
2. Start the application: `python app.py`
3. Visit `http://localhost:5000`
4. Sign in with Google
5. Fetch emails and test AI reply generation
6. Adjust settings in `.env` as needed

---

## Support & Documentation

- **Flask Documentation:** https://flask.palletsprojects.com/
- **Gmail API Guide:** https://developers.google.com/gmail/api
- **Ollama Documentation:** https://ollama.ai/
- **Python Virtual Environments:** https://docs.python.org/3/tutorial/venv.html

---

## License

This project is provided as-is. Modify and distribute as needed.

---

**Setup Date:** 26 March 2026  
**Last Updated:** As per your system date
