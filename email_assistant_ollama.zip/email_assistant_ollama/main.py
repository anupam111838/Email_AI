import time
import sys
from email_service import fetch_unread_emails, send_reply
from ai_service import process_email
from config import AUTO_SEND, EMAIL_ADDRESS

def main():
    print("=" * 50)
    print("🤖 Agentic Email Assistant Starting...")
    print("=" * 50)
    
    if not EMAIL_ADDRESS:
        print("ERROR: Please configure your environment variables in .env first.")
        sys.exit(1)
        
    print(f"Monitoring inbox: {EMAIL_ADDRESS}")
    print(f"Auto-Send Mode: {'ON' if AUTO_SEND else 'OFF (Drafts will just be printed)'}")
    print("-" * 50)

    try:
        while True:
            print(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] Checking for new emails...")
            emails = fetch_unread_emails()
            
            if not emails:
                print("No new emails. Resting...")
            else:
                print(f"Found {len(emails)} new unread email(s)!")
            
            for index, email in enumerate(emails, 1):
                print(f"\n--- Email {index} / {len(emails)} ---")
                print(f"From:    {email['sender']}")
                print(f"Subject: {email['subject']}")
                print(f"Date:    {email['date']}")
                print("Analyzing content with Ollama (gemma3)...")
                
                # Truncate very long email bodies slightly for display and cost saving if desired
                body_content = email['body'][:15000] if email['body'] else "" 
                
                if not body_content.strip():
                    print("Email body is empty. Skipping analysis.")
                    continue
                
                # Call AI service
                summary, reply = process_email(
                    body_content,
                    sender=email.get('sender'),
                    subject=email.get('subject')
                )
                
                print(f"\n📝 SUMMARY:\n{summary}")
                print(f"\n✍️ DRAFT REPLY:\n{reply}")
                
                # Handle Sending
                if AUTO_SEND:
                    print("\n🚀 Auto-send is enabled. Sending reply...")
                    send_reply(email['sender'], email['subject'], reply)
                    print("✅ Reply sent successfully.")
                else:
                    print("\n⚠️ Auto-send is disabled. Reply was NOT sent.")
            
            # Poll every 60 seconds
            time.sleep(60)
            
    except KeyboardInterrupt:
        print("\n🛑 Stopping Email Assistant. Goodbye!")
    except Exception as e:
        print(f"\n❌ An unexpected error occurred: {e}")

if __name__ == "__main__":
    main()
