from __future__ import annotations

import re
import json
from email.utils import parseaddr
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen
from config import OLLAMA_BASE_URL, OLLAMA_MODEL

try:
    from ollama import Client
except ImportError:
    Client = None

# Configure the Ollama API client
client = Client(host=OLLAMA_BASE_URL) if Client and OLLAMA_BASE_URL else None
model = OLLAMA_MODEL or None

CLASSIFICATION_RULES = [
    {
        'key': 'urgent',
        'label': 'Urgent Action',
        'default_priority': 'high',
        'keywords': (
            'urgent', 'asap', 'immediately', 'today', 'tonight', 'deadline',
            'action required', 'respond by', 'final notice', 'time sensitive',
            'approval needed', 'review needed',
        ),
        'sender_keywords': ('alerts', 'security', 'support'),
    },
    {
        'key': 'support',
        'label': 'Support / Issue',
        'default_priority': 'high',
        'keywords': (
            'issue', 'problem', 'bug', 'error', 'failed', 'failure',
            'not working', 'unable to', 'incident', 'outage', 'help needed',
            'ticket', 'support request',
        ),
        'sender_keywords': ('support', 'helpdesk'),
    },
    {
        'key': 'meeting',
        'label': 'Meeting / Schedule',
        'default_priority': 'medium',
        'keywords': (
            'meeting', 'schedule', 'reschedule', 'availability', 'calendar',
            'appointment', 'call', 'zoom', 'google meet', 'teams', 'interview',
            'demo', 'slot',
        ),
        'sender_keywords': ('calendar',),
    },
    {
        'key': 'finance',
        'label': 'Finance / Billing',
        'default_priority': 'medium',
        'keywords': (
            'invoice', 'payment', 'paid', 'billing', 'bill', 'receipt',
            'refund', 'quote', 'pricing', 'tax', 'bank', 'salary', 'payroll',
            'subscription renewal', 'transaction',
        ),
        'sender_keywords': ('billing', 'payments', 'finance'),
    },
    {
        'key': 'travel',
        'label': 'Travel / Booking',
        'default_priority': 'medium',
        'keywords': (
            'flight', 'hotel', 'booking', 'reservation', 'itinerary',
            'boarding', 'check-in', 'trip', 'travel', 'departure', 'arrival',
        ),
        'sender_keywords': ('airlines', 'booking', 'travel'),
    },
    {
        'key': 'career',
        'label': 'Hiring / Career',
        'default_priority': 'medium',
        'keywords': (
            'application', 'resume', 'cv', 'recruiter', 'candidate', 'position',
            'role', 'hiring', 'job opening', 'interview round', 'offer letter',
        ),
        'sender_keywords': ('jobs', 'careers', 'recruit'),
    },
    {
        'key': 'promotions',
        'label': 'Promotions / Marketing',
        'default_priority': 'low',
        'keywords': (
            'discount', 'offer', 'sale', 'promo', 'promotion', 'deal',
            'limited time', 'webinar', 'newsletter', 'unsubscribe',
            'register now', 'launch', 'special offer',
        ),
        'sender_keywords': ('newsletter', 'marketing', 'offers', 'noreply', 'no-reply'),
    },
    {
        'key': 'personal',
        'label': 'Personal',
        'default_priority': 'low',
        'keywords': (
            'birthday', 'party', 'family', 'friend', 'dinner', 'weekend',
            'catch up', 'congratulations', 'congrats', 'wedding', 'vacation',
        ),
        'sender_keywords': (),
    },
]

HIGH_PRIORITY_TERMS = (
    'urgent', 'asap', 'immediately', 'deadline', 'today', 'final notice',
    'action required', 'approval needed', 'respond by', 'security alert',
)
LOW_PRIORITY_TERMS = (
    'newsletter', 'unsubscribe', 'sale', 'discount', 'webinar', 'promo',
    'special offer', 'marketing',
)

REQUEST_TERMS = (
    'please', 'can you', 'could you', 'would you', 'let me know',
    'share', 'send', 'review', 'confirm', 'schedule', 'reply',
)


def _ollama_url(path: str) -> str:
    base_url = (OLLAMA_BASE_URL or "").rstrip("/")
    if not base_url:
        raise RuntimeError("OLLAMA_BASE_URL is not set.")
    return f"{base_url}{path}"


def _ollama_http_request(
    path: str,
    *,
    payload: dict | None = None,
    timeout: float = 90,
) -> dict:
    data = None
    headers: dict[str, str] = {}
    method = 'GET'
    if payload is not None:
        data = json.dumps(payload).encode('utf-8')
        headers['Content-Type'] = 'application/json'
        method = 'POST'

    request = Request(_ollama_url(path), data=data, headers=headers, method=method)

    try:
        with urlopen(request, timeout=timeout) as response:
            body = response.read().decode('utf-8', 'replace')
    except HTTPError as exc:
        detail = exc.read().decode('utf-8', 'replace').strip()
        raise RuntimeError(detail or f"Ollama HTTP error: {exc.code}") from exc
    except URLError as exc:
        raise RuntimeError(f"Ollama connection failed: {exc.reason}") from exc

    if not body.strip():
        return {}

    try:
        return json.loads(body)
    except json.JSONDecodeError as exc:
        raise RuntimeError("Ollama returned invalid JSON.") from exc


def _ollama_chat(
    messages: list[dict[str, str]],
    *,
    response_format: str | None = None,
    temperature: float = 0.6,
) -> dict:
    if not model:
        raise RuntimeError("OLLAMA_MODEL is not configured.")

    if client is not None:
        payload = {
            'model': model,
            'messages': messages,
            'options': {'temperature': temperature},
        }
        if response_format:
            payload['format'] = response_format
        return client.chat(**payload)

    payload = {
        'model': model,
        'messages': messages,
        'stream': False,
        'options': {'temperature': temperature},
    }
    if response_format:
        payload['format'] = response_format
    return _ollama_http_request('/api/chat', payload=payload, timeout=90)


def is_ollama_available(timeout: float = 0.75) -> bool:
    if not model:
        return False

    try:
        payload = _ollama_http_request('/api/tags', timeout=timeout)
    except Exception:
        return False

    models = payload.get('models', [])
    return any(item.get('name') == model for item in models)


def _truncate_text(value: str, limit: int = 600) -> str:
    value = value.strip()
    if len(value) <= limit:
        return value
    return value[:limit - 1].rstrip() + '…'


def _clean_email_text(value: str | None) -> str:
    if not value:
        return ''

    lines: list[str] = []
    for raw_line in value.splitlines():
        line = raw_line.strip()
        lower = line.lower()
        if not line:
            continue
        if line.startswith('>'):
            continue
        if lower.startswith(('from:', 'sent:', 'to:', 'cc:', 'bcc:', 'subject:')):
            continue
        if lower.startswith('on ') and ' wrote:' in lower:
            break
        lines.append(line)

    text = ' '.join(lines)
    text = re.sub(r'\s+', ' ', text).strip()
    return text


def _extract_sentences(value: str, *, limit: int = 3) -> list[str]:
    cleaned = _clean_email_text(value)
    if not cleaned:
        return []

    sentences = [
        sentence.strip(' "\'')
        for sentence in re.split(r'(?<=[.!?])\s+', cleaned)
        if sentence.strip(' "\'')
    ]
    return sentences[:limit]


def _build_local_summary(email_content: str, sender: str | None = None, subject: str | None = None) -> str:
    sentences = _extract_sentences(email_content, limit=2)
    sender_name = _extract_sender_name(sender) or "the sender"
    subject_text = _normalise_space(subject)

    if sentences:
        return _truncate_text(' '.join(sentences), 420)

    if subject_text:
        return f"{sender_name} emailed about {subject_text.lower()}."

    return f"Email received from {sender_name} and needs review."


def _build_local_reply(
    email_content: str,
    *,
    sender: str | None = None,
    subject: str | None = None,
    greeting_rule: str,
    sign_off: str,
) -> str:
    category = categorize_email(
        email_content,
        sender=sender,
        subject=subject,
        use_ai=False,
    )
    cleaned = _clean_email_text(email_content)
    subject_text = _normalise_space(subject)
    subject_fragment = f" regarding {subject_text}" if subject_text else ""
    has_request = '?' in cleaned or any(term in cleaned.lower() for term in REQUEST_TERMS)

    category_message = {
        'urgent': "I understand this appears to be time-sensitive, and I will review it as a priority.",
        'support': "I have noted the issue you described and will look into the next steps carefully.",
        'meeting': "I have noted the scheduling request and will review the available options before confirming.",
        'finance': "I have reviewed the billing-related details and will verify the relevant information before responding further.",
        'travel': "I have noted the travel details and will review the itinerary and next actions.",
        'career': "I have received the hiring-related information and will review it in detail.",
        'promotions': "Thank you for sharing the information.",
        'personal': "Thank you for reaching out.",
        'general': "I have received your message and reviewed the details you shared.",
    }.get(category['key'], "I have received your message and reviewed the details you shared.")

    closing = (
        "If there is a specific deadline or any additional context I should keep in mind, please let me know."
        if has_request or category['priority'] == 'high'
        else "I will follow up after reviewing the details more closely."
    )

    return (
        f"{greeting_rule}\n\n"
        f"Thank you for your email{subject_fragment}. "
        f"{category_message} {closing}\n\n"
        f"{sign_off}"
    ).strip()

def _extract_first_name(value: str | None) -> str | None:
    """
    Return a clean first name (letters only), stripping digits and symbols.
    Example: "anupam6654" -> "Anupam"
    """
    if not value:
        return None

    # Remove numbers, then keep only letters/spaces for a clean name token.
    clean = re.sub(r"\d+", "", value)
    clean = re.sub(r"[^A-Za-z\s]", " ", clean)
    clean = re.sub(r"\s+", " ", clean).strip()

    if not clean:
        return None

    return clean.split()[0].capitalize()

def _extract_sender_name(sender: str | None) -> str | None:
    """
    Extract a human-friendly sender name from formats like:
    - "Anupam Sharma <anupam@example.com>"
    - "anupam.sharma@example.com"
    """
    if not sender:
        return None

    display_name, email_addr = parseaddr(sender)

    # Prefer explicit display name from the email header
    candidate = _extract_first_name((display_name or "").strip().strip("\"'"))
    if candidate:
        return candidate

    # Fallback to local-part of the email address (before @)
    if email_addr and "@" in email_addr:
        local = email_addr.split("@", 1)[0]
        local = re.sub(r"[._\-+]+", " ", local).strip()
        local_name = _extract_first_name(local)
        if local_name:
            return local_name

    return None


def _normalise_space(value: str | None) -> str:
    return re.sub(r'\s+', ' ', value or '').strip()


def _priority_rank(level: str) -> int:
    return {'low': 0, 'medium': 1, 'high': 2}.get(level, 1)


def categorize_email_ai(
    email_content: str,
    sender: str | None = None,
    subject: str | None = None,
) -> dict | None:
    """
    Use Ollama (granite4:latest) to categorize the email and determine priority.
    """
    if model is None:
        return None

    system_prompt = """
You are an intelligent email routing assistant.
Your ONLY task is to analyze an email and output a valid JSON object. Do not output any conversational text or markdown blocks.

Categorization Guidelines:
- "urgent": Time-sensitive actions, critical deadlines, security breaches.
- "support": Technical issues, bug reports, questions about product usage.
- "meeting": Scheduling, calendar invites, availability requests.
- "finance": Invoices, billing statements, payment confirmations.
- "travel": Flight itineraries, hotel bookings.
- "career": Job applications, recruiter messages, offers.
- "promotions": Marketing offers, newsletters, sales pitches.
- "personal": Communication from friends/family, social invites.
- "general": Routine updates, FYIs, or other work emails.

Priority Assignment:
- "high": Needs immediate attention (e.g., urgent/support).
- "medium": Important but not critical (e.g., meeting/finance/career).
- "low": Informational, routine or marketing (e.g., promotions/personal).

Output Format (strict JSON ONLY):
{"key": "finance", "label": "Finance / Billing", "priority": "medium", "reason": "This email contains an invoice attached requiring payment."}
"""

    user_prompt = f"""
Email Metadata:
- Sender: {sender}
- Subject: {subject}

Content:
\"\"\"{email_content[:3000]}\"\"\"
"""
    try:
        response = _ollama_chat(
            [
                {'role': 'system', 'content': system_prompt.strip()},
                {'role': 'user', 'content': user_prompt.strip()}
            ],
            response_format='json',
            temperature=0.1,
        )
        
        text = response['message']['content'].strip()
        # Clean the response text for JSON parsing if needed
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0].strip()
        elif "```" in text:
            text = text.split("```")[1].split("```")[0].strip()
        
        return json.loads(text)
    except Exception as e:
        print(f"Error in AI categorization (Ollama): {e}")
        return None

def categorize_email(
    email_content: str,
    *,
    sender: str | None = None,
    subject: str | None = None,
    use_ai: bool = True
) -> dict:
    """
    Categorize an email using AI as the primary engine for deep understanding.
    Falls back to a keyword-based rule system only as a secondary check or if AI is unavailable.
    """
    subject_text = _normalise_space(subject)
    body_text = _normalise_space(email_content)
    sender_text = _normalise_space(sender).lower()
    combined_text = f"{subject_text.lower()} {body_text.lower()}".strip()

    # AI-First Strategy: Primary path for "understanding"
    if use_ai:
        ai_result = categorize_email_ai(email_content, sender, subject)
        if ai_result:
            return {
                **ai_result,
                'score': 10,  # AI is primary
                'method': 'ai'
            }

    # Rule-based processing as a fallback or for enrichment
    best_rule = None
    best_score = 0
    best_reason = 'Fallback used (Rules).'

    for rule in CLASSIFICATION_RULES:
        score = 0
        matches: list[str] = []

        for keyword in rule['keywords']:
            if keyword in subject_text.lower():
                score += 4
                matches.append(keyword)
            elif keyword in combined_text:
                score += 2
                matches.append(keyword)

        for sender_keyword in rule['sender_keywords']:
            if sender_keyword in sender_text:
                score += 2
                matches.append(f"sender:{sender_keyword}")

        if score > best_score:
            best_rule = rule
            best_score = score
            if matches:
                reason_terms = ', '.join(matches[:3]).replace('sender:', '')
                best_reason = f"Matched {reason_terms} (Rules fallback)."

    if best_rule is None or best_score < 2:
        default_priority = 'medium' if body_text else 'low'
        return {
            'key': 'general',
            'label': 'General Update',
            'priority': default_priority,
            'reason': 'Semantic AI check failed; rules detected no strong patterns.',
            'score': best_score,
            'method': 'rules'
        }

    priority = best_rule['default_priority']
    if any(term in combined_text for term in HIGH_PRIORITY_TERMS):
        priority = 'high'
    elif best_rule['key'] == 'promotions' or any(term in combined_text for term in LOW_PRIORITY_TERMS):
        priority = 'low'
    
    if "security" in sender_text or "alert" in sender_text:
        priority = 'high'

    return {
        'key': best_rule['key'],
        'label': best_rule['label'],
        'priority': priority,
        'reason': best_reason,
        'score': best_score,
        'method': 'rules'
    }

def process_email(email_content: str, sender: str | None = None, subject: str | None = None, my_name: str | None = None, my_email: str | None = None) -> tuple[str, str]:
    """
    Analyzes the email content using Ollama to generate a summary and a draft reply.
    Uses sender metadata to produce a more professional personalized greeting.
    """
    sender_name = _extract_sender_name(sender)
    sender_for_prompt = sender if sender else "Unknown sender"
    subject_for_prompt = subject if subject else "No subject"
    greeting_rule = f'Dear {sender_name},' if sender_name else 'Hello,'

    # Build sign-off with the user's real name
    if my_name:
        sign_off = f'Best regards,\n{my_name}'
    elif my_email:
        local = my_email.split('@')[0]
        name = _extract_first_name(local.replace('.', ' ').replace('_', ' '))
        sign_off = f'Best regards,\n{name}' if name else 'Best regards'
    else:
        sign_off = 'Best regards'

    system_prompt = f"""
You are an expert executive assistant. You must perfectly generate two sections based on the user's email: a SUMMARY and a drafted REPLY.

Instructions:
1. Provide a brief 2-3 sentence summary of the email.
2. Draft a complete, polite, and professional email reply on behalf of your manager.
3. Your draft reply MUST start with exactly: {greeting_rule}
4. Your draft reply MUST end with exactly:
{sign_off}
5. Do NOT include any filler text. Do NOT include conversational AI text.

Your output MUST rigidly match this exact format:

SUMMARY:
<your summary here>

REPLY:
<your draft email here>
"""

    user_prompt = f"""
Email metadata:
Sender: {sender_for_prompt}
Subject: {subject_for_prompt}

Email Content:
\"\"\"
{email_content}
\"\"\"
"""
    
    try:
        if model is None:
            raise RuntimeError("OLLAMA_MODEL is not configured.")

        response = _ollama_chat(
            [
                {'role': 'system', 'content': system_prompt.strip()},
                {'role': 'user', 'content': user_prompt.strip()}
            ],
            temperature=0.6,
        )
        text = response['message']['content'].strip()
        
        summary = ""
        reply = ""
        
        # Parse the structured response
        if "SUMMARY:" in text and "REPLY:" in text:
            parts = text.split("REPLY:", 1)
            summary = parts[0].replace("SUMMARY:", "").strip()
            reply = parts[1].strip()
        elif "REPLY:" in text:
            parts = text.split("REPLY:", 1)
            summary = "Summary could not be precisely extracted."
            reply = parts[1].strip()
        else:
            raise RuntimeError("Unexpected Ollama response format.")
            
        return summary, reply
        
    except Exception as e:
        print(f"Error communicating with Ollama API: {e}")
        return (
            _build_local_summary(email_content, sender=sender, subject=subject),
            _build_local_reply(
                email_content,
                sender=sender,
                subject=subject,
                greeting_rule=greeting_rule,
                sign_off=sign_off,
            ),
        )
