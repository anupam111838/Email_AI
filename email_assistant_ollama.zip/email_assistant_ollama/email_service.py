"""
Email Service — Gmail API
Fetches and sends emails using OAuth2 credentials obtained via the web flow.
"""

from __future__ import annotations

import base64
import binascii
import html as _html
import re
from email.message import EmailMessage

from googleapiclient.discovery import build
from googleapiclient.errors import HttpError


def _build_service(creds):
    """Build a Gmail API service from credentials object."""
    return build('gmail', 'v1', credentials=creds)

DEFAULT_UNREAD_FETCH_LIMIT = 10


def _decode_gmail_body(data: str | None) -> str:
    """
    Gmail message bodies are base64url-encoded and may omit padding.
    Return decoded text, or empty string on decode errors.
    """
    if not data:
        return ""
    try:
        padded = data + ("=" * (-len(data) % 4))
        return base64.urlsafe_b64decode(padded).decode("utf-8", errors="replace")
    except (binascii.Error, ValueError):
        return ""

def _html_to_text(html: str) -> str:
    if not html:
        return ""
    # Remove scripts/styles.
    html = re.sub(r"(?is)<(script|style).*?>.*?</\1>", " ", html)
    # Preserve some structure/newlines before stripping tags.
    html = re.sub(r"(?i)<br\\s*/?>", "\n", html)
    html = re.sub(r"(?i)</(p|div|tr|li|blockquote|h\\d|pre)>", "\n", html)
    html = re.sub(r"(?i)<(p|div|tr|li|blockquote|h\\d|pre)(\\s[^>]*)?>", "\n", html)
    # Strip remaining tags.
    html = re.sub(r"(?s)<[^>]+>", " ", html)
    text = _html.unescape(html)
    # Normalise whitespace while keeping line breaks.
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+\n", "\n", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _extract_text_from_payload(payload: dict | None, *, fetch_attachment=None) -> dict:
    """
    Extract a readable text body from Gmail payloads.
    Returns a dict with:
      - 'text': plain text for AI processing
      - 'html': raw HTML for faithful UI rendering (images, formatting, etc.)
      - 'attachments': list of {filename, mimeType, size, attachmentId}
    Collects nested parts (multipart/*) so forwarded/replied chains are not lost.
    """
    if not payload:
        return {"text": "", "html": "", "attachments": []}

    plain_parts: list[str] = []
    html_parts: list[str] = []
    attachments: list[dict] = []

    def walk(part: dict):
        mime_type = (part.get("mimeType") or "").lower()
        body = part.get("body") or {}
        body_data = body.get("data")
        attachment_id = body.get("attachmentId")
        filename = part.get("filename") or ""

        # Collect attachment metadata (non-inline files with a filename)
        if filename and attachment_id:
            attachments.append({
                'filename': filename,
                'mimeType': mime_type,
                'size': body.get('size', 0),
                'attachmentId': attachment_id,
            })

        # Fetch text/html body parts (even if stored as attachments)
        if (not body_data) and attachment_id and fetch_attachment and mime_type in {"text/plain", "text/html"} and not filename:
            try:
                body_data = fetch_attachment(attachment_id)
            except Exception:
                body_data = None

        if mime_type == "text/plain" and not filename:
            text = _decode_gmail_body(body_data)
            if text.strip():
                plain_parts.append(text)
        elif mime_type == "text/html" and not filename:
            html = _decode_gmail_body(body_data)
            if html.strip():
                html_parts.append(html)

        for child in part.get("parts") or []:
            walk(child)

    walk(payload)

    def join_unique(parts: list[str]) -> str:
        out: list[str] = []
        seen: set[str] = set()
        for p in parts:
            cleaned = p.strip()
            if not cleaned:
                continue
            if cleaned in seen:
                continue
            seen.add(cleaned)
            out.append(cleaned)
        return "\n\n".join(out).strip()

    raw_plain = join_unique(plain_parts)
    raw_html = join_unique(html_parts)
    converted_html_text = _html_to_text(raw_html)

    # Pick best plain text for AI processing
    if raw_plain and not converted_html_text:
        text_body = raw_plain
    elif converted_html_text and not raw_plain:
        text_body = converted_html_text
    elif converted_html_text and (len(converted_html_text) > max(200, int(len(raw_plain) * 1.5))):
        text_body = converted_html_text
    else:
        text_body = raw_plain

    return {"text": text_body, "html": raw_html, "attachments": attachments}


def extract_latest_reply(text: str) -> str:
    """
    Splits an email thread and returns only the newest, top-most message.
    """
    if not text:
        return ""
    
    # Common thread break boundaries
    patterns = [
        r'(?im)^_{32,}\s*$',                                  # Outlook style line
        r'(?im)^\s*-----\s*Original Message\s*-----\s*$',     # Outlook classic
        r'(?im)^On\s+.*,\s+.*(?:wrote|sent):\s*$',            # Gmail / Apple Mail 'On X, Y wrote:'
        r'(?im)^From:\s+.*(?:\n\s*(?:Sent|To|Date|Subject):\s+.*){2,}',  # Exchange plain text 'From: ...' block
    ]
    
    earliest_match = len(text)
    for p in patterns:
        match = re.search(p, text)
        if match:
            earliest_match = min(earliest_match, match.start())
            
    if earliest_match < len(text):
        return text[:earliest_match].strip()
    return text.strip()


def fetch_unread_emails(creds, limit: int = 10) -> list[dict]:
    """
    Uses Gmail API to fetch the most recent unread emails from INBOX
    and mark them as read. `limit` controls how many to fetch.
    """
    if not limit or limit <= 0:
        return []

    service = _build_service(creds)
    emails_data = []

    try:
        profile = service.users().getProfile(userId='me').execute()
        my_email = profile.get('emailAddress', '').lower()

        results = service.users().threads().list(
            userId="me",
            q="is:unread in:inbox",
            maxResults=int(limit),
        ).execute()
        threads = results.get("threads", [])
        if not threads:
            return []

        for th in threads:
            thread_id = th['id']
            try:
                thread_data = service.users().threads().get(
                    userId='me', id=thread_id, format='full'
                ).execute()

                thread_messages = []
                for msg in thread_data.get('messages', []):
                    msg_id = msg['id']
                    headers = msg['payload'].get('headers', [])
                    subject = next((h['value'] for h in headers if h['name'].lower() == 'subject'), 'No Subject')
                    sender = next((h['value'] for h in headers if h['name'].lower() == 'from'), 'Unknown Sender')
                    to_hdr = next((h['value'] for h in headers if h['name'].lower() == 'to'), '')
                    date_str = next((h['value'] for h in headers if h['name'].lower() == 'date'), '')
                    cc = next((h['value'] for h in headers if h['name'].lower() == 'cc'), '')
                    bcc = next((h['value'] for h in headers if h['name'].lower() == 'bcc'), '')

                    def _fetch_attachment(attachment_id: str, m_id=msg_id) -> str | None:
                        att = service.users().messages().attachments().get(
                            userId="me", messageId=m_id, id=attachment_id,
                        ).execute()
                        return att.get("data")

                    body_result = _extract_text_from_payload(msg.get("payload"), fetch_attachment=_fetch_attachment)
                    latest_body = extract_latest_reply(body_result['text'])

                    thread_messages.append({
                        'id': msg_id,
                        'sender': sender,
                        'to_header': to_hdr,
                        'subject': subject,
                        'cc': cc,
                        'bcc': bcc,
                        'body': body_result['text'],
                        'latest_body': latest_body,
                        'html_body': body_result['html'],
                        'attachments': body_result.get('attachments', []),
                        'date': date_str,
                        'internalDate': int(msg.get('internalDate', 0)),
                    })
                
                if not thread_messages:
                    continue

                last_msg = thread_messages[-1]
                
                # Determine smart Reply-To address
                reply_to_address = last_msg['sender']
                # If the last message was sent by the user, the "To" should be whoever they sent it to!
                if my_email and my_email in last_msg['sender'].lower():
                    reply_to_address = last_msg['to_header']

                # Accumulate all CCs across the thread, ensuring the authenticated user is excluded
                all_ccs = []
                for mm in thread_messages:
                    if mm.get('cc'):
                        for addr in mm['cc'].split(','):
                            addr_clean = addr.strip()
                            if addr_clean and my_email not in addr_clean.lower() and addr_clean not in all_ccs:
                                all_ccs.append(addr_clean)
                
                reply_cc = ", ".join(all_ccs)

                emails_data.append({
                    'uid': thread_id,  # Thread ID as the primary identifier
                    'is_thread': True,
                    'messages': thread_messages,
                    'sender': reply_to_address,
                    'subject': last_msg['subject'],
                    'cc': reply_cc,
                    'bcc': last_msg['bcc'],
                    'body': last_msg['body'],
                    'latest_body': last_msg['latest_body'],
                    'html_body': last_msg['html_body'],
                    'attachments': last_msg.get('attachments', []),
                    'date': last_msg['date'],
                    'internalDate': last_msg['internalDate'],
                })

                # Mark thread as read
                try:
                    service.users().threads().modify(
                        userId='me', id=thread_id,
                        body={'removeLabelIds': ['UNREAD']}
                    ).execute()
                except HttpError:
                    pass
            except HttpError as error:
                print(f'Failed to fetch full thread {thread_id}: {error}')

    except HttpError as error:
        print(f'Gmail API fetch error: {error}')
        raise

    # Sort emails to ensure newest (highest internalDate) is first
    emails_data.sort(key=lambda x: x.get('internalDate', 0), reverse=True)
    return emails_data


def send_reply(creds, to_address: str, original_subject: str, reply_body: str, cc_address: str = "", bcc_address: str = "", thread_id: str = ""):
    """Sends an email reply via the Gmail API, appending to a thread if thread_id is provided."""
    service = _build_service(creds)

    try:
        message = EmailMessage()
        message.set_content(reply_body)

        subject = original_subject
        if not subject.lower().startswith('re:'):
            subject = f'Re: {subject}'

        message['To'] = to_address
        message['Subject'] = subject
        if cc_address:
            message['Cc'] = cc_address
        if bcc_address:
            message['Bcc'] = bcc_address

        encoded = base64.urlsafe_b64encode(message.as_bytes()).decode()
        body = {'raw': encoded}
        if thread_id:
            body['threadId'] = thread_id

        service.users().messages().send(
            userId='me', body=body
        ).execute()
        print(f'Reply sent to {to_address} in thread {thread_id}')

    except HttpError as error:
        print(f'Gmail API send error: {error}')
        raise


def get_user_email(creds) -> str:
    """Get the authenticated user's email address."""
    try:
        service = _build_service(creds)
        profile = service.users().getProfile(userId='me').execute()
        return profile.get('emailAddress', 'Unknown')
    except Exception:
        return 'Unknown'
