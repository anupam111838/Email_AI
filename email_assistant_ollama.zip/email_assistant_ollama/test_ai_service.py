import ai_service
from ai_service import categorize_email


def test_categorize_finance_email():
    result = categorize_email(
        "Please find the invoice attached. Payment is due by Friday.",
        sender="billing@vendor.com",
        subject="Invoice for March subscription",
        use_ai=False,
    )

    assert result["key"] == "finance"
    assert result["priority"] in {"medium", "high"}


def test_categorize_support_email():
    result = categorize_email(
        "The production dashboard is not working and users are seeing an error.",
        sender="support@customer.com",
        subject="Urgent: issue in production",
        use_ai=False,
    )

    assert result["key"] in {"support", "urgent"}
    assert result["priority"] == "high"


def test_categorize_promotional_email():
    result = categorize_email(
        "Limited time offer. Register now for our webinar and get a discount.",
        sender="newsletter@company.com",
        subject="Special offer just for you",
        use_ai=False,
    )

    assert result["key"] == "promotions"
    assert result["priority"] == "low"


def test_categorize_general_email_without_signals():
    result = categorize_email(
        "Just sharing the notes from yesterday.",
        sender="teammate@example.com",
        subject="Quick update",
        use_ai=False,
    )

    assert result["key"] == "general"


def test_process_email_uses_ollama_http_fallback_when_python_client_is_missing(monkeypatch):
    fake_response = {
        "message": {
            "content": (
                "SUMMARY:\n"
                "The sender needs confirmation on the invoice timeline.\n\n"
                "REPLY:\n"
                "Dear Alex,\n\n"
                "Thank you for your email. I will review the invoice details and follow up shortly.\n\n"
                "Best regards,\n"
                "Anupam"
            )
        }
    }

    monkeypatch.setattr(ai_service, "client", None)
    monkeypatch.setattr(ai_service, "model", "gemma3:latest")
    monkeypatch.setattr(ai_service, "_ollama_chat", lambda *args, **kwargs: fake_response)

    summary, reply = ai_service.process_email(
        "Please confirm the invoice timeline by Friday.",
        sender="Alex Example <alex@example.com>",
        subject="Invoice timeline",
        my_name="Anupam",
    )

    assert "invoice timeline" in summary.lower()
    assert reply.startswith("Dear Alex,")
    assert "Best regards,\nAnupam" in reply


def test_process_email_returns_local_fallback_when_ollama_call_fails(monkeypatch):
    def fail(*args, **kwargs):
        raise RuntimeError("ollama offline")

    monkeypatch.setattr(ai_service, "model", "gemma3:latest")
    monkeypatch.setattr(ai_service, "_ollama_chat", fail)

    summary, reply = ai_service.process_email(
        "Could you please share the updated meeting time? We need to confirm availability today.",
        sender="Alex Example <alex@example.com>",
        subject="Meeting update",
        my_name="Anupam",
    )

    assert "updated meeting time" in summary.lower() or "availability today" in summary.lower()
    assert reply.startswith("Dear Alex,")
    assert "Thank you for your email regarding Meeting update." in reply
    assert "Best regards,\nAnupam" in reply
