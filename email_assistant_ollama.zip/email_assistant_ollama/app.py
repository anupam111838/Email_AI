"""
AI Email Assistant — Flask Application
OAuth2 "Sign in with Google" web flow + Gmail API.
"""

from __future__ import annotations

import os
import time
import uuid
import base64
import binascii
import logging
import threading
from datetime import datetime

from flask import Flask, render_template, jsonify, request, redirect, url_for, session, Response

import google.oauth2.credentials
import google_auth_oauthlib.flow

from email_service import fetch_unread_emails, send_reply, get_user_email, _build_service
from ai_service import process_email, categorize_email, is_ollama_available
from config import UNREAD_FETCH_LIMIT, EMAIL_QUEUE_LIMIT

from werkzeug.middleware.proxy_fix import ProxyFix

# ─── App ─────────────────────────────────────────────────────────────────────────

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_prefix=1)
app.config['SECRET_KEY'] = os.urandom(24)

# Allow HTTP for local development (OAuth2 usually requires HTTPS)
os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s  %(levelname)-8s  %(message)s',
    datefmt='%H:%M:%S',
)
log = logging.getLogger('email-assistant')

@app.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 0 seconds.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

def _static_version() -> str:
    """
    Cache-bust static assets so UI updates (buttons, CSS) show up without manual hard refresh.
    """
    paths = [
        os.path.join(app.root_path, "static", "css", "style.css"),
        os.path.join(app.root_path, "static", "js", "app.js"),
    ]
    mtimes = []
    for p in paths:
        try:
            mtimes.append(int(os.path.getmtime(p)))
        except OSError:
            mtimes.append(0)
    return str(sum(mtimes))

# ─── OAuth Config ────────────────────────────────────────────────────────────────

CLIENT_SECRETS_FILE = 'credentials.json'
SCOPES = ['https://www.googleapis.com/auth/gmail.modify']

# ─── In-Memory State ────────────────────────────────────────────────────────────

active_sessions = {}
account_states = {}
sessions_lock = threading.Lock()

def _prepend_and_trim(state: dict, new_emails: list[dict], fetch_limit: int = 0) -> list[dict]:
    """
    Prepend new emails to the queue and keep only the most recent EMAIL_QUEUE_LIMIT or fetch_limit (whichever is higher).
    Returns the list of truly new items (not previously in the queue).
    Must be called while holding state['lock'].
    """
    if not new_emails:
        return []

    old_uids = [e.get('uid') for e in state.get('emails', []) if e.get('uid')]
    existing_uids = set(old_uids)
    truly_new = [e for e in new_emails if e.get('uid') and e.get('uid') not in existing_uids]

    active_limit = max(int(EMAIL_QUEUE_LIMIT), fetch_limit)
    combined = truly_new + state.get('emails', [])
    combined.sort(key=lambda x: int(x.get('internalDate', 0)), reverse=True)
    state['emails'] = combined[:active_limit]
    keep_uids = {e.get('uid') for e in state['emails'] if e.get('uid')}
    state['processed'] = {uid: v for uid, v in state.get('processed', {}).items() if uid in keep_uids}
    new_uids = [e.get('uid') for e in state.get('emails', []) if e.get('uid')]
    if new_uids != old_uids:
        state['queue_version'] = int(state.get('queue_version') or 0) + 1

    return [e for e in truly_new if e.get('uid') in keep_uids]


def _categorize_emails(emails: list[dict]) -> list[dict]:
    """Attach stable category metadata to every fetched email."""
    enriched = []
    for mail in emails:
        category = categorize_email(
            mail.get('latest_body', mail.get('body', '')),
            sender=mail.get('sender'),
            subject=mail.get('subject'),
        )
        enriched.append({
            **mail,
            'category': {
                'key': category['key'],
                'label': category['label'],
                'priority': category['priority'],
                'reason': category['reason'],
            },
        })
    return enriched


def _new_state():
    return {
        'lock': threading.Lock(),
        'logged_in': False,
        'email': None,
        'credentials': None,
        'emails': [],
        'processed': {},
        'queue_version': 0,
        'auto_pilot': False,
        'auto_send': False,
        'pilot_status': 'Idle',
        'last_fetch': None,
    }


def get_account_state(account_key: str):
    with sessions_lock:
        if account_key not in account_states:
            account_states[account_key] = _new_state()
        return account_states[account_key]


def get_user_state():
    """Return current browser state."""
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    sid = session['session_id']

    with sessions_lock:
        account_key = session.get('account_key')
        if account_key and account_key in account_states:
            return account_states[account_key]

        if sid not in active_sessions:
            active_sessions[sid] = _new_state()
        return active_sessions[sid]

# def get_redirect_uri():
#     """
#     Pick an OAuth redirect base URL for local development.

#     Override via:
#     - APP_URL (e.g. http://localhost:8000)
#     """
#     app_url = (os.getenv("APP_URL") or "").rstrip("/")
#     if app_url:
#         return app_url
#     return request.url_root.rstrip("/")


def get_redirect_uri():
    """
    Pick an OAuth redirect base URL that works for:
    - Same machine (server + browser): use localhost
    - Different machine on LAN: use the nip.io hostname

    Override defaults via:
    - LOCAL_APP_URL (default: http://localhost:8000)
    - LAN_APP_URL   (default: http://192.168.0.57.nip.io:8000)
    """
    local_app_url = (os.getenv("LOCAL_APP_URL") or "http://localhost:8000").rstrip("/") 

    configured_lan_url = (os.getenv("LAN_APP_URL") or os.getenv("APP_URL") or "").rstrip("/")
    if configured_lan_url and "127.0.0.1" not in configured_lan_url and "localhost" not in configured_lan_url:
        lan_app_url = configured_lan_url
    else:
        lan_app_url = "http://192.168.0.57.nip.io:8000"

    host = (request.host or "").lower()
    host_no_port = host.split(":", 1)[0].strip("[]")
    is_local_host = host_no_port in {"localhost", "127.0.0.1", "::1"}
    return local_app_url if is_local_host else lan_app_url

# ─── Auto-Pilot Background Worker ───────────────────────────────────────────────

def _auto_pilot_loop():
    while True:
        with sessions_lock: 
            # Auto-pilot runs on logged-in shared account states.
            sessions_list = list(account_states.values())
            
        for s in sessions_list:
            if s['auto_pilot'] and s['logged_in'] and s['credentials']:
                with s['lock']:
                    s['pilot_status'] = 'Polling inbox…'
                try:
                    creds = s['credentials']
                    new = _categorize_emails(fetch_unread_emails(creds, limit=UNREAD_FETCH_LIMIT))
                    if new:
                        with s['lock']:
                            truly_new = _prepend_and_trim(s, new, UNREAD_FETCH_LIMIT)
                            s['last_fetch'] = datetime.now().strftime('%H:%M:%S')

                        for mail in truly_new:
                            uid = mail['uid']
                            if uid not in s['processed']:
                                with s['lock']:
                                    s['pilot_status'] = f"Analysing mail from {mail.get('sender', '?')}…"
                                summary, draft = process_email(
                                    mail.get('latest_body', mail.get('body', ''))[:15000],
                                    sender=mail.get('sender'),
                                    subject=mail.get('subject'),
                                    my_email=s.get('email'),
                                )
                                sent = False
                                if s['auto_send']:
                                    with s['lock']:
                                        s['pilot_status'] = 'Sending auto-reply…'
                                    send_reply(
                                        creds, mail['sender'], mail['subject'], draft,
                                        cc_address=mail.get('cc', ''), bcc_address=mail.get('bcc', ''),
                                        thread_id=uid
                                    )
                                    sent = True
                                with s['lock']:
                                    s['processed'][uid] = {
                                        'summary': summary,
                                        'draft': draft,
                                        'sent': sent,
                                    }
                    else:
                        with s['lock']:
                            s['pilot_status'] = 'No new mail — waiting…'
                except Exception as exc:
                    log.exception('Auto-pilot error')
                    with s['lock']:
                        s['pilot_status'] = f'Error: {exc}'
            elif s['logged_in']:
                with s['lock']:
                    if not s['auto_pilot']:
                        s['pilot_status'] = 'Idle'
            else:
                with s['lock']:
                    s['pilot_status'] = 'Not logged in'
        time.sleep(15)

threading.Thread(target=_auto_pilot_loop, daemon=True).start()


# ─── Page Routes ─────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    """Serve the app. Also handles the OAuth callback (Google redirects here with ?code=...)."""

    # ── OAuth callback ────────────────────────────────────────────────────────
    code = request.args.get('code')
    if code:
        try:
            flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
                CLIENT_SECRETS_FILE,
                scopes=SCOPES,
                redirect_uri=get_redirect_uri(),
            )
            flow.fetch_token(authorization_response=request.url)
            credentials = flow.credentials

            user_email = get_user_email(credentials)
            account_key = (user_email or 'unknown').strip().lower()
            session['account_key'] = account_key
            session['detached'] = False
            state = get_account_state(account_key)

            with state['lock']:
                state['logged_in'] = True
                state['email'] = user_email
                state['credentials'] = credentials
                if state['pilot_status'] == 'Not logged in':
                    state['pilot_status'] = 'Idle'

            # Auto-fetch emails in the background so redirect is instant
            def _initial_fetch(creds, email, s_dict):
                try:
                    with s_dict['lock']:
                        s_dict['pilot_status'] = 'Fetching initial emails…'
                    new = _categorize_emails(fetch_unread_emails(creds, limit=UNREAD_FETCH_LIMIT))
                    with s_dict['lock']:
                        truly_new = _prepend_and_trim(s_dict, new, UNREAD_FETCH_LIMIT)
                        s_dict['last_fetch'] = datetime.now().strftime('%H:%M:%S')
                        s_dict['pilot_status'] = 'Idle'
                    log.info(f'Logged in as {email}, fetched {len(truly_new)} emails')
                except Exception as exc:
                    log.exception('Auto-fetch after login failed')
                    with s_dict['lock']:
                        s_dict['pilot_status'] = 'Initial fetch failed'

            # Optional: Uncomment below to re-enable auto-fetching on login
            # threading.Thread(target=_initial_fetch, args=(credentials, user_email, state), daemon=True).start()

            # Clean redirect (remove OAuth query params from URL)
            return redirect(url_for('index'))

        except Exception as exc:
            log.exception('OAuth callback error')

    # ── Normal page load ──────────────────────────────────────────────────────
    has_ai_backend = is_ollama_available()
    has_creds_file = os.path.exists(CLIENT_SECRETS_FILE)
    return render_template(
        'index.html',
        has_ai_backend=has_ai_backend,
        has_creds_file=has_creds_file,
        static_version=_static_version(),
    )


# ─── OAuth Routes ────────────────────────────────────────────────────────────────

@app.route('/auth/login')
def auth_login():
    """Redirect user to Google's OAuth consent page."""
    if not os.path.exists(CLIENT_SECRETS_FILE):
        return jsonify({'error': 'credentials.json not found'}), 500
    session['detached'] = False

    flow = google_auth_oauthlib.flow.Flow.from_client_secrets_file(
        CLIENT_SECRETS_FILE,
        scopes=SCOPES,
        redirect_uri=get_redirect_uri(),
    )

    authorization_url, flow_state = flow.authorization_url(
        access_type='offline',
        include_granted_scopes='true',
        prompt='consent',
    )

    session['oauth_state'] = flow_state
    return redirect(authorization_url)


@app.route('/api/logout', methods=['POST'])
def api_logout():
    # Local-only logout: detach this browser from shared account state.
    session.pop('account_key', None)
    session['detached'] = True
    return jsonify({'message': 'Logged out from this browser.'})


# ─── State API ───────────────────────────────────────────────────────────────────

@app.route('/api/state')
def api_state():
    state = get_user_state()
    with state['lock']:
        return jsonify({
            'logged_in': state['logged_in'],
            'email': state['email'],
            'emails': state['emails'],
            'processed': state['processed'],
            'queue_version': state.get('queue_version', 0),
            'auto_pilot': state['auto_pilot'],
            'auto_send': state['auto_send'],
            'pilot_status': state['pilot_status'],
            'last_fetch': state['last_fetch'],
            'total': len(state['emails']),
            'processed_count': len(state['processed']),
            'sent_count': sum(1 for v in state['processed'].values() if v.get('sent')),
        })


# ─── Email API ───────────────────────────────────────────────────────────────────

@app.route('/api/fetch', methods=['POST'])
def api_fetch():
    state = get_user_state()
    if not state['logged_in'] or not state['credentials']:
        return jsonify({'error': 'Not logged in.'}), 401
    
    data = request.json or {}
    fetch_limit = int(data.get('limit', UNREAD_FETCH_LIMIT))
    
    try:
        creds = state['credentials']
        new = _categorize_emails(fetch_unread_emails(creds, limit=fetch_limit))
        with state['lock']:
            truly_new = _prepend_and_trim(state, new, fetch_limit)
            state['last_fetch'] = datetime.now().strftime('%H:%M:%S')
        return jsonify({'message': f'Fetched {len(truly_new)} new email(s).', 'count': len(truly_new)})
    except Exception as exc:
        log.exception('Fetch error')
        return jsonify({'error': str(exc)}), 500


@app.route('/api/generate/<uid>', methods=['POST'])
def api_generate(uid):
    state = get_user_state()
    if not state['logged_in']:
        return jsonify({'error': 'Not logged in.'}), 401
    mail = next((e for e in state['emails'] if e['uid'] == uid), None)
    if not mail:
        return jsonify({'error': 'Email not found.'}), 404
    summary, draft = process_email(
        mail.get('latest_body', mail.get('body', ''))[:15000],
        sender=mail.get('sender'),
        subject=mail.get('subject'),
        my_email=state.get('email'),
    )
    with state['lock']:
        state['processed'][uid] = {'summary': summary, 'draft': draft, 'sent': False}
    return jsonify({'summary': summary, 'draft': draft})


@app.route('/api/send/<uid>', methods=['POST'])
def api_send(uid):
    state = get_user_state()
    if not state['logged_in'] or not state['credentials']:
        return jsonify({'error': 'Not logged in.'}), 401
    if uid not in state['processed']:
        return jsonify({'error': 'Generate a reply first.'}), 400
    mail = next((e for e in state['emails'] if e['uid'] == uid), None)
    if not mail:
        return jsonify({'error': 'Email not found.'}), 404

    body = (request.json or {}).get('draft', state['processed'][uid]['draft'])
    to_address = (request.json or {}).get('to', mail.get('sender', ''))
    cc_address = (request.json or {}).get('cc', mail.get('cc', ''))
    bcc_address = (request.json or {}).get('bcc', mail.get('bcc', ''))

    creds = state['credentials']
    send_reply(
        creds, to_address, mail['subject'], body,
        cc_address=cc_address, bcc_address=bcc_address,
        thread_id=uid
    )
    with state['lock']:
        state['processed'][uid]['sent'] = True
        state['processed'][uid]['draft'] = body
    return jsonify({'message': 'Reply sent!'})


@app.route('/api/clear', methods=['POST'])
def api_clear():
    state = get_user_state()
    with state['lock']:
        state['emails'].clear()
        state['processed'].clear()
        state['last_fetch'] = None
        state['queue_version'] = int(state.get('queue_version') or 0) + 1
    return jsonify({'message': 'Queue cleared.'})


@app.route('/api/autopilot', methods=['POST'])
def api_autopilot():
    state = get_user_state()
    if not state['logged_in']:
        return jsonify({'error': 'Not logged in.'}), 401
    data = request.json or {}
    with state['lock']:
        if 'auto_pilot' in data:
            state['auto_pilot'] = bool(data['auto_pilot'])
        if 'auto_send' in data:
            state['auto_send'] = bool(data['auto_send'])
    return jsonify({
        'auto_pilot': state['auto_pilot'],
        'auto_send': state['auto_send'],
    })


@app.route('/api/attachment/<thread_id>/<msg_id>/<att_id>')
def api_attachment(thread_id, msg_id, att_id):
    """Download an email attachment via Gmail API."""
    state = get_user_state()
    if not state['logged_in'] or not state['credentials']:
        return jsonify({'error': 'Not logged in.'}), 401

    # Find the attachment metadata from our cached emails
    filename = 'attachment'
    mime_type = 'application/octet-stream'
    mail = next((e for e in state['emails'] if e['uid'] == thread_id), None)
    if mail:
        target_msg = next((m for m in mail.get('messages', []) if m['id'] == msg_id), None)
        if target_msg:
            att_meta = next(
                (a for a in target_msg.get('attachments', []) if a.get('attachmentId') == att_id),
                None,
            )
            if att_meta:
                filename = att_meta.get('filename', 'attachment')
                mime_type = att_meta.get('mimeType', 'application/octet-stream')

    try:
        service = _build_service(state['credentials'])
        att = service.users().messages().attachments().get(
            userId='me', messageId=msg_id, id=att_id,
        ).execute()
        data = att.get('data', '')
        # Gmail returns base64url-encoded data
        padded = data + ('=' * (-len(data) % 4))
        file_bytes = base64.urlsafe_b64decode(padded)

        return Response(
            file_bytes,
            mimetype=mime_type,
            headers={
                'Content-Disposition': f'attachment; filename="{filename}"',
                'Content-Length': str(len(file_bytes)),
            },
        )
    except Exception as exc:
        log.exception('Attachment download error')
        return jsonify({'error': str(exc)}), 500


# ─── Entry-point ─────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    log.info('Starting AI Email Assistant on http://0.0.0.0:8000')
    try:
        from waitress import serve
        log.info('Serving with Waitress (Production WSGI server)...')
        serve(app, host='0.0.0.0', port=8000)
    except ImportError:
        log.warning('Waitress not installed. Falling back to Flask dev server (may be slow on LAN).')
        app.run(debug=True, host='0.0.0.0', port=8000)
