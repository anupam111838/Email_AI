# AI Email Assistant

An autonomous email assistant powered by **Ollama (granite4 AI)** and the **Gmail API (OAuth 2.0)**. It reads unread emails, generates summaries, drafts contextual replies, and can optionally send them automatically — all through a beautiful Flask web interface.

## Features

- **OAuth 2.0 Gmail Integration** — Secure access to your inbox via Google's official API; no app-passwords needed.
- **AI-Powered Analysis** — Ollama (granite4:latest) summarises each email and drafts a professional, personalised reply.
- **Auto-Pilot Mode** — Background polling fetches, analyses, and optionally sends replies hands-free.
- **Modern Web UI** — Dark Glassmorphism design with animated backgrounds, toast notifications, and responsive layout.

---

## Setup Instructions

### 1. Install Ollama & Pull granite4

```bash
# Install from https://ollama.com
ollama pull granite4:latest
```

### 2. Clone & Navigate

```bash
cd "/media/nepra/nepra-1 TB/Projects/agentic_ai/updated/openclaw/email_assistant"
```

### 2. Virtual Environment (recommended)

```bash
python -m venv venv
source venv/bin/activate  # Linux / macOS
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Environment Configuration

Copy and fill in your `.env`:

```bash
cp .env.example .env
```

| Variable         | Description |
|------------------|-------------|
| `EMAIL_ADDRESS`  | Your Gmail address (display only) |
| `OLLAMA_BASE_URL` | Local or remote Ollama server URL (e.g. `http://localhost:11434`) |
| `OLLAMA_MODEL`    | The Ollama model to use (e.g. `granite4:latest`) |
| `AUTO_SEND`      | `False` by default — set to `True` for automatic replies |

### 5. Google OAuth Setup

Place `credentials.json` (OAuth 2.0 Client ID JSON from [Google Cloud Console](https://console.cloud.google.com/)) in this directory. The first run will open a browser tab for you to authorise the app.

---

## Running the Application

### Web UI (Flask)

```bash
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

### CLI Mode

```bash
python main.py
```

---

## Project Structure

```
email_assistant/
├── app.py              # Flask web server & REST API
├── main.py             # CLI agent (polling loop)
├── config.py           # Environment variable loader
├── email_service.py    # Gmail API — fetch & send
├── ai_service.py       # Ollama AI — summarise & draft
├── oauth_service.py    # Google OAuth 2.0 flow
├── requirements.txt
├── .env                # Your secrets (not committed)
├── credentials.json    # Google OAuth client ID
├── templates/
│   └── index.html      # Jinja2 template
└── static/
    ├── css/
    │   └── style.css   # Design system
    └── js/
        └── app.js      # Client-side logic
```
