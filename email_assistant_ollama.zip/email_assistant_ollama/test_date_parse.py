import re
from datetime import datetime
from email.utils import parsedate_to_datetime

dates = [
    "Tue, 10 Mar 2026 11:38:00 +0530",
    "20 Aug 2025 10:00:00 GMT",
    "Fri, 15 Nov 2024 16:20:00 -0400"
]

for d in dates:
    try:
        dt = parsedate_to_datetime(d)
        print(f"'{d}' -> {dt}")
    except Exception as e:
        print(f"Error parsing '{d}': {e}")
