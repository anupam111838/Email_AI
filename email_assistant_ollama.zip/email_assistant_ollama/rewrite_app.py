import re

with open('app.py', 'r') as f:
    original_code = f.read()

# Replace state and locks
new_state_block = """# ─── In-Memory State ────────────────────────────────────────────────────────────

import uuid

active_sessions = {}
sessions_lock = threading.Lock()

def get_user_state():
    if 'session_id' not in session:
        session['session_id'] = str(uuid.uuid4())
    sid = session['session_id']
    with sessions_lock:
        if sid not in active_sessions:
            active_sessions[sid] = {
                'lock': threading.Lock(),
                'logged_in': False,
                'email': None,
                'credentials': None,
                'emails': [],
                'processed': {},
                'auto_pilot': False,
                'auto_send': False,
                'pilot_status': 'Idle',
                'last_fetch': None,
            }
        return active_sessions[sid]

def get_redirect_uri():
    app_url = os.getenv('APP_URL', '').rstrip('/')
    if app_url and '127.0.0.1' not in app_url and 'localhost' not in app_url:
        return app_url
    return request.url_root.rstrip('/')
"""

import sys
# It's better if I just write out the complete file to avoid messy sed/regex
