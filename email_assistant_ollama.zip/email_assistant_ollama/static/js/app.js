/* ═══════════════════════════════════════════════════════════════════════
   AI Email Agent — Clean White Professional UI
   ═══════════════════════════════════════════════════════════════════════ */

const App = (() => {
    let state = {
        logged_in: false, email: null, emails: [], processed: {},
        queue_version: 0, auto_pilot: false, auto_send: false,
        pilot_status: 'Idle', last_fetch: null,
        total: 0, processed_count: 0, sent_count: 0,
    };
    let pollTimer = null;
    let selectedUid = null;

    const $ = s => document.querySelector(s);
    const $$ = s => document.querySelectorAll(s);

    const api = async (url, opts = {}) => {
        const headers = { ...(opts.headers || {}) };
        if (opts.body && !('Content-Type' in headers)) headers['Content-Type'] = 'application/json';
        const res = await fetch(url, { credentials: 'same-origin', ...opts, headers });
        const text = await res.text();
        let data = {};
        if (text) { try { data = JSON.parse(text); } catch { data = { message: text.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim() }; } }
        if (!res.ok) throw new Error(data.error || data.message || res.statusText);
        return data;
    };

    const esc = s => { if (!s) return ''; const d = document.createElement('div'); d.textContent = s; return d.innerHTML; };
    const escAttr = s => (s || '').replace(/&/g, '&amp;').replace(/"/g, '&quot;');
    const getCat = e => e.category || { key: 'general', label: 'General', priority: 'medium', reason: '', method: 'none' };

    /* ── Toast ───────────────────────────────────────────────────────── */
    const toast = (msg, type = 'info') => {
        const c = $('#toasts'), el = document.createElement('div');
        el.className = `toast ${type}`;
        const icons = { success: '✓', error: '✕', info: 'ℹ' };
        el.innerHTML = `<span class="toast-icon">${icons[type] || 'ℹ'}</span><span>${esc(msg)}</span>`;
        c.appendChild(el);
        setTimeout(() => { el.style.opacity = '0'; el.style.transform = 'translateX(16px)'; setTimeout(() => el.remove(), 300); }, 4800);
    };

    /* ── Screens ─────────────────────────────────────────────────────── */
    const showLogin = () => { $('#app-shell').classList.add('hidden'); const l = $('#login-screen'); l.classList.remove('hidden'); l.style.opacity = '0'; requestAnimationFrame(() => { l.style.transition = 'opacity .4s ease'; l.style.opacity = '1'; }); startPolling(); };
    const showApp = () => { $('#login-screen').classList.add('hidden'); const a = $('#app-shell'); a.classList.remove('hidden'); a.style.opacity = '0'; requestAnimationFrame(() => { a.style.transition = 'opacity .4s ease'; a.style.opacity = '1'; }); $('#account-email').textContent = state.email || ''; startPolling(); };

    /* ── Polling ─────────────────────────────────────────────────────── */
    const startPolling = () => { if (pollTimer) clearInterval(pollTimer); pollTimer = setInterval(poll, 3000); };

    const poll = async () => {
        try {
            const data = await api('/api/state');
            const wasLoggedIn = state.logged_in;
            const changed = (data.queue_version ?? 0) !== (state.queue_version ?? 0) || data.total !== state.total || data.processed_count !== state.processed_count || data.sent_count !== state.sent_count;
            state = data;
            if (state.logged_in) {
                if (!wasLoggedIn) { showApp(); render(); toast(`Connected as ${state.email}`, 'success'); }
                else { updateSidebar(); if (changed) { render(); if (selectedUid) renderDetail(selectedUid); } }
            } else if (wasLoggedIn) showLogin();
        } catch (err) { console.warn('Poll:', err); }
    };

    /* ── Sidebar ─────────────────────────────────────────────────────── */
    const updateSidebar = () => {
        const urgentCount = state.emails.filter(e => { const c = getCat(e); return c.priority === 'high' || c.key === 'urgent'; }).length;
        animateNum('stat-total', state.total); animateNum('stat-ai', state.processed_count);
        animateNum('stat-sent', state.sent_count); animateNum('stat-urgent', urgentCount);
        animateNum('stat-total2', state.total); animateNum('stat-ai2', state.processed_count); animateNum('stat-sent2', state.sent_count);
        $('#pilot-text').textContent = state.pilot_status;
        $('#pilot-chip').classList.toggle('active', state.auto_pilot);
        if (document.activeElement !== $('#sw-autopilot')) $('#sw-autopilot').checked = state.auto_pilot;
        if (document.activeElement !== $('#sw-autosend')) $('#sw-autosend').checked = state.auto_send;
        if (state.last_fetch) { $('#last-fetch-info').style.display = ''; $('#last-fetch-time').textContent = state.last_fetch; }
    };

    const animateNum = (id, v) => {
        const el = document.getElementById(id); if (!el) return;
        if ((parseInt(el.textContent) || 0) === v) return;
        el.textContent = v; el.style.transition = 'none'; el.style.transform = 'scale(1.3)';
        requestAnimationFrame(() => { el.style.transition = 'transform .4s cubic-bezier(.34,1.56,.64,1)'; el.style.transform = 'scale(1)'; });
    };

    /* ── Render Helpers ──────────────────────────────────────────────── */
    const DARK_EMAIL_CSS = `<style>
        html,body{background:#fff!important;color:#374151!important;font-family:'DM Sans',system-ui,sans-serif!important;font-size:13.5px!important;line-height:1.75!important;padding:8px!important;margin:0!important}
        a{color:#4f46e5!important}
        img{max-width:100%!important}
        blockquote{border-left:2px solid #e5e7eb!important;padding-left:10px!important;color:#6b7280!important}
        pre,code{background:#f3f4f6!important;border-radius:4px!important;padding:2px 5px!important;font-size:.9em!important}
        .gmail_quote,.moz-cite-prefix{color:#9ca3af!important}
    </style>`;

    const renderEmailBody = email => {
        const isTrail = email.latest_body && email.latest_body.length < (email.body || '').length - 10;
        if (!isTrail && email.html_body && email.html_body.trim()) {
            const darkHtml = email.html_body.replace(/<head>/i, `<head>${DARK_EMAIL_CSS}`)
                .replace(/^(<html[^>]*>)/, `$1<head>${DARK_EMAIL_CSS}</head>`)
                || (DARK_EMAIL_CSS + email.html_body);
            const src = email.html_body.includes('<head') ? email.html_body.replace(/<head([^>]*)>/i, `<head$1>${DARK_EMAIL_CSS}`) : DARK_EMAIL_CSS + email.html_body;
            return `<iframe class="email-iframe" srcdoc="${escAttr(src)}" sandbox="allow-same-origin" frameborder="0" scrolling="auto" onload="this.style.height=Math.min(this.contentDocument.body.scrollHeight+20,500)+'px'"></iframe>`;
        }
        return `<div class="email-text-body">${esc(email.latest_body || email.body || '').replace(/\n/g, '<br>')}</div>`;
    };

    const formatSize = b => { if (!b || b <= 0) return ''; if (b < 1024) return b + ' B'; if (b < 1048576) return (b/1024).toFixed(1)+' KB'; return (b/1048576).toFixed(1)+' MB'; };
    const fIcon = m => { if (!m) return '📎'; if (m.startsWith('image/')) return '🖼️'; if (m === 'application/pdf') return '📄'; if (m.includes('sheet')||m.includes('excel')) return '📊'; if (m.includes('document')||m.includes('word')) return '📝'; return '📎'; };

    const renderAtts = (msg, tid) => {
        const atts = msg.attachments; if (!atts || !atts.length) return '';
        const tId = tid || msg.uid, mId = msg.id || msg.uid;
        const chips = atts.map(a => {
            const url = `/api/attachment/${encodeURIComponent(tId)}/${encodeURIComponent(mId)}/${encodeURIComponent(a.attachmentId)}`;
            return `<a class="attachment-chip" href="${url}" target="_blank" download="${esc(a.filename)}"><span class="att-icon">${fIcon(a.mimeType)}</span><span class="att-name">${esc(a.filename)}</span>${formatSize(a.size) ? `<span class="att-size">${formatSize(a.size)}</span>` : ''}</a>`;
        }).join('');
        return `<div class="attachments-bar"><span class="att-label">📎 ${atts.length} Attachment${atts.length > 1 ? 's' : ''}</span><div class="att-list">${chips}</div></div>`;
    };

    const showSkeleton = () => {
        let s = '';
        for (let i = 0; i < 5; i++) s += `<div class="erow" style="animation-delay:${i*.05}s;pointer-events:none;opacity:.5"><div class="e-top"><div class="skeleton skeleton-line" style="width:${40+Math.random()*30}%;height:10px;border-radius:4px"></div><div class="skeleton skeleton-line" style="width:50px;height:9px;border-radius:4px"></div></div><div class="skeleton skeleton-line medium" style="height:9px;border-radius:4px;margin-top:5px"></div><div class="skeleton skeleton-line short" style="height:8px;border-radius:4px;margin-top:4px"></div></div>`;
        $('#inbox').innerHTML = s;
    };

    /* ══════════════════════════════════════════════════════════════════
       RENDER EMAIL LIST
       ══════════════════════════════════════════════════════════════════ */
    const render = () => {
        const el = $('#inbox');
        if (!state.emails.length) { el.innerHTML = `<div class="empty-state"><div class="empty-icon">📬</div><h3>Your inbox is clear</h3><p>Click <strong>Fetch Emails</strong> to pull unread messages.</p></div>`; return; }

        el.innerHTML = state.emails.map((email, idx) => {
            const p = state.processed[email.uid], sent = p && p.sent, hasAI = !!p;
            const cat = getCat(email);
            const sender = (email.sender || '?'), sChar = sender.replace(/[^a-zA-Z]/g, '').charAt(0).toUpperCase() || '?';
            const sDisplay = esc(sender).split('&lt;')[0].trim();
            const date = (email.date || '').replace(/\s*\(.*?\)\s*$/, '').replace(/\s+[-+]\d{4}$/, '');
            const snippet = esc(email.latest_body || email.body || '').substring(0, 80).replace(/\n/g, ' ');
            const msgs = email.messages || [email];
            const hasAtts = msgs.some(m => m.attachments && m.attachments.length > 0);
            let badge = sent
                ? '<span class="chip chip-gr">✓ sent</span>'
                : hasAI ? '<span class="chip chip-v">✦ ready</span>' : '';
            const catKey = (cat.key || 'general').toLowerCase();
            const catChip = `<span class="chip chip-${catKey === 'urgent' ? 'r' : catKey === 'work' ? 'v' : catKey === 'personal' ? 'gr' : catKey === 'finance' ? 'g' : 'n'}">${esc(cat.label)}</span>`;
            const priChip = cat.priority === 'high' ? '<span class="chip chip-r">high</span>' : cat.priority === 'medium' ? '<span class="chip chip-a">medium</span>' : '';

            return `<div class="erow ${selectedUid === email.uid ? 'active' : ''} ${!hasAI && !sent ? 'unread' : ''}" onclick="App.selectEmail('${email.uid}')" style="animation-delay:${idx*.03}s">
                <div class="e-top"><span class="e-from">${sDisplay}</span><span class="e-date">${esc(date)}</span></div>
                <div class="e-subj">${hasAtts ? '⊕ ' : ''}${esc(email.subject)}${msgs.length > 1 ? ` <span style="opacity:.35;font-size:.65rem">(${msgs.length})</span>` : ''}</div>
                <div class="e-snip">${snippet}</div>
                <div class="badges">${badge}${catChip}${priChip}</div>
            </div>`;
        }).join('');
        updateSidebar();
    };

    /* ══════════════════════════════════════════════════════════════════
       RENDER DETAIL PANEL
       ══════════════════════════════════════════════════════════════════ */
    const selectEmail = uid => {
        selectedUid = uid;
        $$('.erow').forEach(el => el.classList.remove('active'));
        const items = $$('.erow'), idx = state.emails.findIndex(e => e.uid === uid);
        if (idx >= 0 && items[idx]) items[idx].classList.add('active');
        renderDetail(uid);
    };

    const renderDetail = uid => {
        const email = state.emails.find(e => e.uid === uid); if (!email) return;
        $('#detail-empty').style.display = 'none';
        const dv = $('#detail-view'); dv.style.display = 'flex'; dv.classList.remove('hidden');
        dv.dataset.uid = uid;

        const sDisplay = esc(email.sender || '?').split('&lt;')[0].trim();
        const cat = getCat(email);
        $('#detail-subject').textContent = email.subject || '';
        $('#detail-meta').textContent = `${sDisplay}  ·  ${email.date || ''}`;

        const p = state.processed[email.uid], sent = p && p.sent, hasAI = !!p;
        const msgs = email.messages || [email], lastMsg = msgs[msgs.length - 1];
        let html = '';

        // Category bar
        html += `<div class="detail-badge-bar">
            <span class="category-chip">${esc(cat.label)}</span>
            <span class="priority-chip priority-${esc(cat.priority)}">${esc(cat.priority)} priority</span>
            ${cat.reason ? `<span class="reason-chip" title="${escAttr(cat.reason)}">${esc(cat.reason).substring(0, 60)}${cat.reason.length > 60 ? '…' : ''}</span>` : ''}
        </div>`;

        // Thread history — Gmail-style stacked cards
        if (msgs.length > 1) {
            html += '<div class="thread-history">';
            for (let i = 0; i < msgs.length - 1; i++) {
                const m = msgs[i];
                const sd = esc(m.sender || '?').split('&lt;')[0].trim();
                const sc = (m.sender || '?').replace(/[^a-zA-Z]/g, '').charAt(0).toUpperCase() || '?';
                const snip = esc(m.latest_body || m.body || '').substring(0, 80).replace(/\n/g, ' ');
                const dt = (m.date || '').replace(/\s*\(.*?\)\s*$/, '');
                html += `<div class="thread-msg-collapsed" onclick="this.classList.toggle('expanded');event.stopPropagation()">
                    <div class="thread-msg-header">
                        <div class="sender-avatar">${sc}</div>
                        <span class="sender-name">${sd}</span>
                        <span class="thread-snippet">${snip}</span>
                        <span class="sender-date">${esc(dt)}</span>
                        <span class="expand-chevron">▼</span>
                    </div>
                    <div class="thread-msg-body">
                        ${renderEmailBody(m)}
                        ${renderAtts(m, email.uid)}
                    </div>
                </div>`;
            }
            html += '</div>';
        }

        // Latest message
        html += '<div class="thread-latest-msg">';
        if (!hasAI) {
            html += `<div class="email-body-content">${renderEmailBody(lastMsg)}</div>
                ${renderAtts(lastMsg, email.uid)}
                <div class="center-action"><button class="btn btn-primary btn-large" id="gen-${email.uid}" onclick="App.generate(event,'${email.uid}')"><span class="btn-sparkle">✦</span> Summarise & Generate Draft</button></div>`;
        } else {
            const sendBtn = sent ? `<div class="sent-badge-large"><span>✓</span> Reply Sent</div>` : `<button class="btn btn-success btn-large" id="send-${email.uid}" onclick="App.send('${email.uid}')">Send Reply</button>`;
            html += `<div class="email-body-content collapsed-preview">${renderEmailBody(lastMsg)}</div>
                ${renderAtts(lastMsg, email.uid)}
                <div class="ai-results">
                    <div class="ai-box ai-summary-box">
                        <div class="ai-box-header"><span class="ai-icon">✦</span> AI Summary</div>
                        <div class="ai-summary-text">${esc(p.summary).replace(/\n/g, '<br>')}</div>
                    </div>
                    <div class="ai-box ai-draft-box">
                        <div class="ai-box-header"><span class="ai-icon">✎</span> Draft Reply</div>
                        <div class="recipient-row"><label>To:</label><input type="text" class="text-input" id="to-${email.uid}" value="${escAttr(email.sender||'')}" ${sent?'disabled':''}>
                            <div style="display:flex">${!email.cc&&!sent?`<span class="add-recipient-link" onclick="document.getElementById('cc-row-${email.uid}').style.display='flex';this.style.display='none'">Cc</span>`:''} ${!email.bcc&&!sent?`<span class="add-recipient-link" onclick="document.getElementById('bcc-row-${email.uid}').style.display='flex';this.style.display='none'">Bcc</span>`:''}</div>
                        </div>
                        <div class="recipient-row" id="cc-row-${email.uid}" style="${!email.cc?'display:none':''}"><label>Cc:</label><input type="text" class="text-input" id="cc-${email.uid}" value="${escAttr(email.cc||'')}" ${sent?'disabled':''}></div>
                        <div class="recipient-row" id="bcc-row-${email.uid}" style="${!email.bcc?'display:none':''}"><label>Bcc:</label><input type="text" class="text-input" id="bcc-${email.uid}" value="${escAttr(email.bcc||'')}" ${sent?'disabled':''}></div>
                        <textarea class="draft-input" id="draft-${email.uid}" ${sent?'disabled':''}>${esc(p.draft)}</textarea>
                        <div class="action-bar">${sendBtn}</div>
                    </div>
                </div>`;
        }
        html += '</div>';
        $('#detail-body').innerHTML = html;

        setTimeout(() => { $$('#detail-body iframe.email-iframe').forEach(f => { try { const d = f.contentDocument || f.contentWindow.document; if (d && d.body) f.style.height = Math.min(d.body.scrollHeight + 20, 500) + 'px'; } catch(e) {} }); }, 200);
    };

    /* ── Actions ──────────────────────────────────────────────────────── */
    const generate = async (e, uid) => {
        if (e) e.stopPropagation();
        const btn = document.getElementById(`gen-${uid}`);
        if (btn) { btn.innerHTML = '<span class="spin"></span> Analysing…'; btn.disabled = true; }
        try { await api(`/api/generate/${uid}`, { method: 'POST' }); toast('AI analysis complete', 'success'); await poll(); render(); renderDetail(uid); }
        catch (err) { toast(err.message, 'error'); if (btn) { btn.innerHTML = '<span class="btn-sparkle">✦</span> Summarise & Generate Draft'; btn.disabled = false; } }
    };

    const send = async uid => {
        const draft = document.getElementById(`draft-${uid}`)?.value;
        const to = document.getElementById(`to-${uid}`)?.value;
        const cc = document.getElementById(`cc-${uid}`)?.value;
        const bcc = document.getElementById(`bcc-${uid}`)?.value;
        const btn = document.getElementById(`send-${uid}`);
        if (btn) { btn.innerHTML = '<span class="spin"></span> Sending…'; btn.disabled = true; }
        try { await api(`/api/send/${uid}`, { method: 'POST', body: JSON.stringify({ draft, to, cc, bcc }) }); toast('Reply sent!', 'success'); await poll(); render(); renderDetail(uid); }
        catch (err) { toast(err.message, 'error'); if (btn) { btn.innerHTML = 'Send Reply'; btn.disabled = false; } }
    };

    const fetchEmails = async () => {
        const btn = $('#btn-fetch'), orig = btn.innerHTML, limit = parseInt($('#sel-limit')?.value || 10, 10);
        btn.innerHTML = '<span class="spin"></span> Fetching…'; btn.disabled = true; showSkeleton();
        try { const data = await api('/api/fetch', { method: 'POST', body: JSON.stringify({ limit }) }); toast(data.message, data.count > 0 ? 'success' : 'info'); await poll(); render(); }
        catch (err) { toast(err.message, 'error'); render(); }
        finally { btn.innerHTML = orig; btn.disabled = false; }
    };

    const toggleAutoPilot = async () => {
        try { await api('/api/autopilot', { method: 'POST', body: JSON.stringify({ auto_pilot: $('#sw-autopilot').checked, auto_send: $('#sw-autosend').checked }) }); toast('Autopilot updated', 'info'); await poll(); }
        catch (err) { toast(err.message, 'error'); }
    };

    const clearData = async () => {
        if (!confirm('Clear entire email queue?')) return;
        try { await api('/api/clear', { method: 'POST' }); toast('Queue cleared', 'success'); selectedUid = null; $('#detail-empty').style.display = ''; const dv = $('#detail-view'); dv.style.display = 'none'; dv.classList.add('hidden'); await poll(); render(); }
        catch (err) { toast(err.message, 'error'); }
    };

    const logout = async () => {
        try { await api('/api/logout', { method: 'POST' }); state = { logged_in: false, email: null, emails: [], processed: {}, queue_version: 0, auto_pilot: false, auto_send: false, pilot_status: 'Idle', last_fetch: null, total: 0, processed_count: 0, sent_count: 0 }; selectedUid = null; showLogin(); toast('Signed out'); }
        catch (err) { toast(err.message, 'error'); }
    };

    /* ── Modal ────────────────────────────────────────────────────────── */
    const openEmail = e => {
        if (e) e.stopPropagation();
        const uid = selectedUid || $('#detail-view')?.dataset?.uid;
        const email = state.emails.find(em => em.uid === uid); if (!email) return;
        $('#modal-subject').textContent = email.subject || '';
        $('#modal-meta').textContent = `${email.sender || ''}  ·  ${email.date || ''}`;
        const mb = $('#modal-body');
        const modalSrc = email.html_body && email.html_body.trim()
            ? (email.html_body.includes('<head') ? email.html_body.replace(/<head([^>]*)>/i, `<head$1>${DARK_EMAIL_CSS}`) : DARK_EMAIL_CSS + email.html_body)
            : null;
        mb.innerHTML = modalSrc
            ? `<iframe class="modal-iframe" srcdoc="${escAttr(modalSrc)}" sandbox="allow-same-origin" frameborder="0" scrolling="auto" onload="this.style.height=Math.min(this.contentDocument.body.scrollHeight+20,600)+'px'"></iframe>`
            : `<div class="email-text-body">${esc(email.body || '').replace(/\n/g,'<br>')}</div>`;
        $('#email-modal').classList.remove('hidden');
    };
    const closeEmailModal = () => { const m = $('#email-modal'); m.style.opacity = '0'; setTimeout(() => { m.classList.add('hidden'); m.style.opacity = ''; }, 220); };
    const handleModalClick = e => { if (e.target === $('#email-modal')) closeEmailModal(); };

    document.addEventListener('keydown', e => { if (e.key === 'Escape') { const m = $('#email-modal'); if (m && !m.classList.contains('hidden')) closeEmailModal(); } });

    const init = async () => { try { const data = await api('/api/state'); state = data; if (state.logged_in) { showApp(); render(); } else showLogin(); } catch { showLogin(); } };

    return { init, logout, fetchEmails, generate, send, toggleAutoPilot, clearData, selectEmail, openEmail, closeEmailModal, handleModalClick };
})();

document.addEventListener('DOMContentLoaded', App.init);