import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Email Configuration (No longer needed for IMAP, keeping for UI display if needed)
EMAIL_ADDRESS = os.getenv("EMAIL_ADDRESS")

# AI Configuration
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "gemma3")

# Application Configuration
AUTO_SEND_STR = os.getenv("AUTO_SEND", "False").lower()
AUTO_SEND = AUTO_SEND_STR in ("true", "1", "yes", "t")

# Fetch configuration
def _int_env(name: str, default: int, *, min_value: int = 1, max_value: int = 200) -> int:
    raw = os.getenv(name, "").strip()
    if not raw:
        return default
    try:
        value = int(raw)
    except ValueError:
        return default
    return max(min_value, min(max_value, value))


# How many unread emails to fetch per poll/fetch request.
UNREAD_FETCH_LIMIT = _int_env("UNREAD_FETCH_LIMIT", 10, min_value=1, max_value=50)

# How many emails to keep in the UI queue (caps growth over time).
EMAIL_QUEUE_LIMIT = _int_env("EMAIL_QUEUE_LIMIT", 200, min_value=1, max_value=500)

# Check required configuration
if not OLLAMA_BASE_URL:
    print("WARNING: OLLAMA_BASE_URL is not set. Defaulting to http://localhost:11434")
